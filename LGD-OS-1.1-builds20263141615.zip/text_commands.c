// text_commands.c
#include "declarations.h"
#include <string.h>
#include <ctype.h>

// cat���� - ��ʾ�ļ�����
int cmd_cat(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out) {
    int i;
    char real_path[MAX_PATH_LEN];
    FILE *fp;
    char buffer[MAX_CONTENT_LEN];
    size_t bytes_read;

    // ���û�в������ӱ�׼�����ȡ
    if (argc < 2) {
        if (in == stdin) {
            fprintf(out, "cat: �ӱ�׼�����ȡ����Ctrl+Z��������...\n");
        }

        while ((bytes_read = fread(buffer, 1, MAX_CONTENT_LEN - 1, in)) > 0) {
            buffer[bytes_read] = '\0';
            fprintf(out, "%s", buffer);
        }
        return 0;
    }

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-") == 0) {
            // �ӱ�׼�����ȡ
            while ((bytes_read = fread(buffer, 1, MAX_CONTENT_LEN - 1, in)) > 0) {
                buffer[bytes_read] = '\0';
                fprintf(out, "%s", buffer);
            }
        } else {
            char virtual_path[MAX_PATH_LEN];
            if (strcmp(ctx->current_dir, "/") == 0) {
                snprintf(virtual_path, MAX_PATH_LEN, "/%s", argv[i]);
            } else {
                snprintf(virtual_path, MAX_PATH_LEN, "%s/%s", ctx->current_dir, argv[i]);
            }

            virtual_to_real_path(virtual_path, real_path);

            if (_access(real_path, 0) != 0) {
                fprintf(out, "cat: �ļ�������: %s\n", argv[i]);
                continue;
            }

            if (!is_file(real_path)) {
                fprintf(out, "cat: �����ļ�: %s\n", argv[i]);
                continue;
            }

            fp = fopen(real_path, "r");
            if (fp == NULL) {
                fprintf(out, "cat: �޷����ļ�: %s\n", argv[i]);
                continue;
            }

            while ((bytes_read = fread(buffer, 1, MAX_CONTENT_LEN - 1, fp)) > 0) {
                buffer[bytes_read] = '\0';
                fprintf(out, "%s", buffer);
            }
            fprintf(out,"\n");
            fclose(fp);
        }
    }

    return 0;
}

// edit���� - �༭�ı��ļ�
int cmd_edit(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out) {
    int i;
    char real_path[MAX_PATH_LEN];
    char temp_path[MAX_PATH_LEN];
    char edit_cmd[MAX_PATH_LEN + 50];
    FILE *fp;

    (void)in;  /* ���δʹ�ã����⾯�� */

    if (argc < 2) {
        fprintf(out, "edit: ȱ�ٲ���\n");
        fprintf(out, "�÷�: edit <�ļ���>\n");
        return 1;
    }

    for (i = 1; i < argc; i++) {
        char virtual_path[MAX_PATH_LEN];
        if (strcmp(ctx->current_dir, "/") == 0) {
            snprintf(virtual_path, MAX_PATH_LEN, "/%s", argv[i]);
        } else {
            snprintf(virtual_path, MAX_PATH_LEN, "%s/%s", ctx->current_dir, argv[i]);
        }

        virtual_to_real_path(virtual_path, real_path);

        char *ext = strrchr(real_path, '.');
        if (ext == NULL || (strcmp(ext, ".txt") != 0 && strcmp(ext, ".log") != 0)) {
            snprintf(temp_path, MAX_PATH_LEN, "%s.txt", real_path);
        } else {
            strcpy(temp_path, real_path);
        }

        if (_access(temp_path, 0) != 0) {
            fp = fopen(temp_path, "w");
            if (fp != NULL) {
                fclose(fp);
                fprintf(out, "�������ļ�: %s\n", argv[i]);
            } else {
                fprintf(out, "edit: �޷������ļ�: %s\n", argv[i]);
                continue;
            }
        }

        fprintf(out, "���ڴ��ļ�: %s\n", temp_path);

        #ifdef _WIN32
            snprintf(edit_cmd, MAX_PATH_LEN + 50, "notepad \"%s\"", temp_path);
        #else
            snprintf(edit_cmd, MAX_PATH_LEN + 50, "xdg-open \"%s\"", temp_path);
        #endif

        int result = system(edit_cmd);

        if (result == 0) {
            fprintf(out, "�ļ��ѱ���: %s\n", argv[i]);
        } else {
            fprintf(out, "����: �༭�����ط���״̬: %d\n", result);
        }
    }

    return 0;
}

// echo���� - ����ı�
int cmd_echo(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out) {
    int i;
    int newline = 1;

    (void)ctx;  /* ���δʹ�ã����⾯�� */
    (void)in;   /* ���δʹ�ã����⾯�� */

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-n") == 0) {
            newline = 0;
        } else {
            fprintf(out, "%s", argv[i]);
            if (i < argc - 1) {
                fprintf(out, " ");
            }
        }
    }

    if (newline) {
        fprintf(out, "\n");
    }

    return 0;
}

// grep���� - �����ı�
int cmd_grep(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out) {
    int i;
    char pattern[MAX_FILENAME] = "";
    int ignore_case = 0;
    int line_number = 0;
    int count_only = 0;

    (void)ctx;  /* ���δʹ�ã����⾯�� */

    if (argc < 2) {
        fprintf(out, "grep: ȱ�ٲ���\n");
        fprintf(out, "�÷�: grep [ѡ��] <ģʽ> [�ļ�...]\n");
        return 1;
    }

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-i") == 0) {
            ignore_case = 1;
        } else if (strcmp(argv[i], "-n") == 0) {
            line_number = 1;
        } else if (strcmp(argv[i], "-c") == 0) {
            count_only = 1;
        } else if (argv[i][0] != '-') {
            strcpy(pattern, argv[i]);
            break;
        }
    }

    if (strlen(pattern) == 0) {
        fprintf(out, "grep: ��Ҫ����ģʽ\n");
        return 1;
    }

    char lower_pattern[MAX_FILENAME];
    if (ignore_case) {
        for (i = 0; pattern[i]; i++) {
            lower_pattern[i] = tolower(pattern[i]);
        }
        lower_pattern[i] = '\0';
    }

    int total_matches = 0;

    if (i >= argc) {
        char line[MAX_CONTENT_LEN];
        int line_num = 0;

        while (fgets(line, sizeof(line), in) != NULL) {
            line_num++;
            char *match = NULL;

            if (ignore_case) {
                char lower_line[MAX_CONTENT_LEN];
                for (int j = 0; line[j]; j++) {
                    lower_line[j] = tolower(line[j]);
                }
                match = strstr(lower_line, lower_pattern);
            } else {
                match = strstr(line, pattern);
            }

            if (match) {
                total_matches++;
                if (!count_only) {
                    if (line_number) {
                        fprintf(out, "%d:", line_num);
                    }
                    fprintf(out, "%s", line);
                }
            }
        }
    } else {
        for (; i < argc; i++) {
            char real_path[MAX_PATH_LEN];
            char virtual_path[MAX_PATH_LEN];

            if (strcmp(ctx->current_dir, "/") == 0) {
                snprintf(virtual_path, MAX_PATH_LEN, "/%s", argv[i]);
            } else {
                snprintf(virtual_path, MAX_PATH_LEN, "%s/%s", ctx->current_dir, argv[i]);
            }

            virtual_to_real_path(virtual_path, real_path);

            if (_access(real_path, 0) != 0) {
                fprintf(out, "grep: �ļ�������: %s\n", argv[i]);
                continue;
            }

            FILE *fp = fopen(real_path, "r");
            if (!fp) {
                fprintf(out, "grep: �޷����ļ�: %s\n", argv[i]);
                continue;
            }

            char line[MAX_CONTENT_LEN];
            int line_num = 0;
            int file_matches = 0;

            while (fgets(line, sizeof(line), fp) != NULL) {
                line_num++;
                char *match = NULL;

                if (ignore_case) {
                    char lower_line[MAX_CONTENT_LEN];
                    for (int j = 0; line[j]; j++) {
                        lower_line[j] = tolower(line[j]);
                    }
                    match = strstr(lower_line, lower_pattern);
                } else {
                    match = strstr(line, pattern);
                }

                if (match) {
                    total_matches++;
                    file_matches++;
                    if (!count_only) {
                        if (line_number) {
                            fprintf(out, "%d:", line_num);
                        }
                        fprintf(out, "%s", line);
                    }
                }
            }

            fclose(fp);

            if (count_only) {
                fprintf(out, "%s: %d\n", argv[i], file_matches);
            }
        }
    }

    if (count_only && i < argc) {
        fprintf(out, "�ܼ�: %d\n", total_matches);
    }

    return 0;
}

// wc���� - ͳ������
int cmd_wc(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out) {
    int i;
    int count_lines = 1;
    int count_words = 1;
    int count_chars = 1;
    int count_bytes = 1;

    (void)ctx;  /* ���δʹ�ã����⾯�� */

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-l") == 0) {
            count_words = 0;
            count_chars = 0;
            count_bytes = 0;
        } else if (strcmp(argv[i], "-w") == 0) {
            count_lines = 0;
            count_chars = 0;
            count_bytes = 0;
        } else if (strcmp(argv[i], "-c") == 0) {
            count_lines = 0;
            count_words = 0;
            count_chars = 0;
        } else if (strcmp(argv[i], "-m") == 0) {
            count_lines = 0;
            count_words = 0;
            count_bytes = 0;
        } else if (argv[i][0] == '-') {
            // ��Чѡ��
        } else {
            break;
        }
    }

    int total_lines = 0;
    int total_words = 0;
    int total_chars = 0;
    int total_bytes = 0;

    if (i >= argc) {
        char line[MAX_CONTENT_LEN];

        while (fgets(line, sizeof(line), in) != NULL) {
            total_lines++;
            total_bytes += strlen(line);

            for (int j = 0; line[j]; j++) {
                total_chars++;
            }

            int in_word = 0;
            for (int j = 0; line[j]; j++) {
                if (isspace(line[j])) {
                    in_word = 0;
                } else if (!in_word) {
                    in_word = 1;
                    total_words++;
                }
            }
        }

        if (count_lines) fprintf(out, "%d ", total_lines);
        if (count_words) fprintf(out, "%d ", total_words);
        if (count_chars) fprintf(out, "%d ", total_chars);
        if (count_bytes) fprintf(out, "%d ", total_bytes);
        fprintf(out, "\n");
    } else {
        for (; i < argc; i++) {
            char real_path[MAX_PATH_LEN];
            char virtual_path[MAX_PATH_LEN];

            if (strcmp(ctx->current_dir, "/") == 0) {
                snprintf(virtual_path, MAX_PATH_LEN, "/%s", argv[i]);
            } else {
                snprintf(virtual_path, MAX_PATH_LEN, "%s/%s", ctx->current_dir, argv[i]);
            }

            virtual_to_real_path(virtual_path, real_path);

            if (_access(real_path, 0) != 0) {
                fprintf(out, "wc: �ļ�������: %s\n", argv[i]);
                continue;
            }

            FILE *fp = fopen(real_path, "r");
            if (!fp) {
                fprintf(out, "wc: �޷����ļ�: %s\n", argv[i]);
                continue;
            }

            int file_lines = 0;
            int file_words = 0;
            int file_chars = 0;
            int file_bytes = 0;
            char line[MAX_CONTENT_LEN];

            while (fgets(line, sizeof(line), fp) != NULL) {
                file_lines++;
                file_bytes += strlen(line);

                for (int j = 0; line[j]; j++) {
                    file_chars++;
                }

                int in_word = 0;
                for (int j = 0; line[j]; j++) {
                    if (isspace(line[j])) {
                        in_word = 0;
                    } else if (!in_word) {
                        in_word = 1;
                        file_words++;
                    }
                }
            }

            fclose(fp);

            if (count_lines) fprintf(out, "%d ", file_lines);
            if (count_words) fprintf(out, "%d ", file_words);
            if (count_chars) fprintf(out, "%d ", file_chars);
            if (count_bytes) fprintf(out, "%d ", file_bytes);
            fprintf(out, "%s\n", argv[i]);

            total_lines += file_lines;
            total_words += file_words;
            total_chars += file_chars;
            total_bytes += file_bytes;
        }

        if (argc - i > 1) {
            if (count_lines) fprintf(out, "%d ", total_lines);
            if (count_words) fprintf(out, "%d ", total_words);
            if (count_chars) fprintf(out, "%d ", total_chars);
            if (count_bytes) fprintf(out, "%d ", total_bytes);
            fprintf(out, "�ܼ�\n");
        }
    }

    return 0;
}



#ifdef _WIN32
#include <conio.h>  // ���� _getch() ����
#endif


// more���� - ��ҳ��ʾ�ļ�����
int cmd_more(ShellContext *ctx, int argc, char *argv[], FILE *in, FILE *out) {
    (void)ctx;  // ���δʹ��

    int lines_per_page = 24;  // Ĭ��ÿҳ24��
    FILE *source = NULL;
    int is_stdin = 0;
    int ch;
    int line_count = 0;
    int page_count = 0;
    char buffer[MAX_PATH_LEN];  // ʹ��MAX_PATH_LEN���MAX_INPUT_LEN
    int i = 1;

    // ����ѡ��
    while (i < argc) {
        if (strcmp(argv[i], "-n") == 0) {
            if (i + 1 < argc) {
                lines_per_page = atoi(argv[i + 1]);
                if (lines_per_page <= 0) {
                    lines_per_page = 24;
                }
                i += 2;
            } else {
                fprintf(out, "����: -n ѡ����Ҫ����\n");
                return 1;
            }
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            fprintf(out, "more - ��ҳ��ʾ�ļ�����\n");
            fprintf(out, "�÷�: more [ѡ��] [�ļ���...]\n");
            fprintf(out, "ѡ��:\n");
            fprintf(out, "  -n NUM    ÿҳ��ʾNUM�У�Ĭ��Ϊ24�У�\n");
            fprintf(out, "  -h, --help ��ʾ�˰�����Ϣ\n");
            fprintf(out, "\nע��:\n");
            fprintf(out, "  1. ���û��ָ���ļ�������ӱ�׼�����ȡ\n");
            fprintf(out, "  2. ֧�ֹܵ�����: ls | more\n");
            fprintf(out, "  3. ֧����ʾ����ļ�\n");
            fprintf(out, "\n��ݼ�:\n");
            fprintf(out, "  �ո��: ��һҳ\n");
            fprintf(out, "  Enter��: ��һ��\n");
            fprintf(out, "  q��: �˳�\n");
            fprintf(out, "\nʾ��:\n");
            fprintf(out, "  more file.txt          # ��ʾ�ļ�\n");
            fprintf(out, "  more -n 10 file.txt    # ÿҳ10����ʾ�ļ�\n");
            fprintf(out, "  cat file.txt | more    # �ӹܵ���ȡ\n");
            fprintf(out, "  ls | more              # ��ҳ��ʾĿ¼�б�\n");
            return 0;
        } else if (argv[i][0] == '-') {
            fprintf(out, "����: δ֪ѡ�� '%s'\n", argv[i]);
            return 1;
        } else {
            break;
        }
    }

    // �ж��Ƿ����ļ�������
    if (i < argc) {
        // ���ļ������������ļ���ȡ
        char real_path[MAX_PATH_LEN];
        virtual_to_real_path(argv[i], real_path);
        source = fopen(real_path, "r");
        if (source == NULL) {
            fprintf(out, "����: �޷����ļ� '%s'\n", argv[i]);
            return 1;
        }
        is_stdin = 0;
    } else {
        // û���ļ�������������Ƿ�ӹܵ�����
        if (in == stdin) {
            // û�йܵ�����
            fprintf(out, "����: û��ָ������Դ\n");
            fprintf(out, "�÷�:\n");
            fprintf(out, "  more �ļ���        # ��ʾ�ļ�����\n");
            fprintf(out, "  ���� | more        # ��ʾ�������\n");
            fprintf(out, "\n���� 'more -h' ��ȡ��ϸ����\n");
            return 1;
        }
        // �ӹܵ�/��׼�����ȡ
        source = in;
        is_stdin = 1;
    }

    // �����ն�Ϊ�޻���ģʽ���Ա�������ȡ����
    #ifdef _WIN32
    #include <conio.h>
    #else
    #include <termios.h>
    #include <unistd.h>
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    #endif

    // ��ҳ��ʾ
    while (fgets(buffer, sizeof(buffer), source) != NULL) {
        fputs(buffer, out);
        line_count++;

        if (line_count >= lines_per_page) {
            page_count++;
            fprintf(out, "-- �� %d ҳ�����ո��������Enter��һ�У�q�˳� --", page_count);
            fflush(out);

            // �ȴ��û�����
            #ifdef _WIN32
            ch = _getch();
            #else
            ch = getchar();
            #endif

            if (ch == 'q' || ch == 'Q') {
                fprintf(out, "\n");
                break;
            } else if (ch == ' ') {
                // �ո������һҳ
                fprintf(out, "\r\033[K");  // �����ǰ��
                line_count = 0;
            } else if (ch == '\r' || ch == '\n') {
                // Enter������һ��
                fprintf(out, "\r\033[K");  // �����ǰ��
                // line_count���䣬����ֻ������ʾһ��
            } else {
                // ������������ʾ����
                fprintf(out, "\n��ݼ�: �ո�=��һҳ, Enter=��һ��, q=�˳�\n");
                fprintf(out, "-- ������ʾ --");
                fflush(out);
                #ifdef _WIN32
                ch = _getch();
                #else
                ch = getchar();
                #endif
                if (ch == 'q' || ch == 'Q') {
                    fprintf(out, "\n");
                    break;
                }
                fprintf(out, "\r\033[K");
                line_count = 0;
            }
        }
    }

    // �ָ��ն�����
    #ifndef _WIN32
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    #endif

    // ������Ǳ�׼���룬�ر��ļ�
    if (!is_stdin && source != NULL) {
        fclose(source);
    }

    // �����ȫ��ʾ���
    if (feof(source)) {
        if (page_count > 0) {
            fprintf(out, "\n-- �ѵ��ļ�ĩβ --\n");
        }
    } else if (ferror(source)) {
        fprintf(out, "\n����: ��ȡ�ļ�ʱ��������\n");
        return 1;
    }

    return 0;
}
