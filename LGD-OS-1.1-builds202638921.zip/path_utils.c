// path_utils.c
#include "declarations.h"

// ��ȡ�淶������·��
/*void get_normalized_virtual_path(const char *virtual_path, char *normalized_virtual) {
    char temp_path[MAX_PATH_LEN];
    char *token;
    char *tokens[100];
    int token_count = 0;

    // ��������·��
    strcpy(temp_path, virtual_path);

    // �ָ�·��
    token = strtok(temp_path, "/");
    while (token != NULL && token_count < 100) {
        tokens[token_count++] = token;
        token = strtok(NULL, "/");
    }

    // ���� .. �� .
    int i = 0;
    for (int j = 0; j < token_count; j++) {
        if (strcmp(tokens[j], "..") == 0) {
            if (i > 0) i--;
        } else if (strcmp(tokens[j], ".") != 0) {
            tokens[i++] = tokens[j];
        }
    }

    // �����淶��·��
    normalized_virtual[0] = '\0';
    if (virtual_path[0] == '/') {
        strcat(normalized_virtual, "/");
    }

    for (int j = 0; j < i; j++) {
        strcat(normalized_virtual, tokens[j]);
        if (j < i - 1) {
            strcat(normalized_virtual, "/");
        }
    }

    if (i == 0 && normalized_virtual[0] == '\0') {
        strcpy(normalized_virtual, "/");
    }
}*/

// �淶��·�������� . �� ..
void normalize_path(char *path) {
    char parts[MAX_ARGS][MAX_FILENAME];
    int part_count = 0;
    char temp_path[MAX_PATH_LEN];
    char result_path[MAX_PATH_LEN];
    int i;

    // ������ʱ·��
    strcpy(temp_path, path);

    // ����ǿ�·�������ظ�Ŀ¼
    if (strlen(temp_path) == 0) {
        strcpy(path, "/");
        return;
    }

    // ���·���Ǹ�Ŀ¼��ֱ�ӷ���
    if (strcmp(temp_path, "/") == 0) {
        return;
    }

    // ������ͷ��/
    char *start = temp_path;
    if (start[0] == '/') {
        start++;
    }

    // ��·���ָ�ɲ���
    char *token = strtok(start, "/");
    while (token != NULL && part_count < MAX_ARGS) {
        strcpy(parts[part_count], token);
        part_count++;
        token = strtok(NULL, "/");
    }

    // ���� . �� ..
    int stack[MAX_ARGS];
    int stack_top = 0;

    for (i = 0; i < part_count; i++) {
        if (strcmp(parts[i], ".") == 0) {
            // ��ǰĿ¼������
            continue;
        } else if (strcmp(parts[i], "..") == 0) {
            // �ϼ�Ŀ¼
            if (stack_top > 0) {
                stack_top--;
            }
        } else if (strlen(parts[i]) > 0) {
            // ����Ŀ¼��
            if (stack_top < MAX_ARGS) {
                stack[stack_top] = i;
                stack_top++;
            }
        }
    }

    // ���¹���·��
    if (stack_top == 0) {
        strcpy(result_path, "/");
    } else {
        result_path[0] = '\0';
        for (i = 0; i < stack_top; i++) {
            strcat(result_path, "/");
            strcat(result_path, parts[stack[i]]);
        }
    }

    strcpy(path, result_path);
}



// ������·��ת��Ϊ��ʵ·��
void virtual_to_real_path(const char *virtual_path, char *real_path) {
    int i;
    char temp_path[MAX_PATH_LEN];

    // ���� ~
    if (strcmp(virtual_path, "~") == 0) {
        // �û���Ŀ¼
        snprintf(real_path, MAX_PATH_LEN, "%s\\home\\user", BUILDS_DIR);
    } else if (strncmp(virtual_path, "~/", 2) == 0) {
        // ~/path
        char temp[MAX_PATH_LEN];
        strcpy(temp, virtual_path + 2);

        // �淶��·��
        normalize_path(temp);

        if (strcmp(temp, "/") == 0) {
            snprintf(real_path, MAX_PATH_LEN, "%s\\home\\user", BUILDS_DIR);
        } else {
            const char *rel_path = (temp[0] == '/') ? temp + 1 : temp;
            snprintf(temp_path, MAX_PATH_LEN, "%s\\home\\user\\%s", BUILDS_DIR, rel_path);

            // ��·���е�/�滻Ϊ
            for (i = 0; temp_path[i] != '\0'; i++) {
                if (temp_path[i] == '/') {
                    temp_path[i] = '\\';
                }
            }
            strcpy(real_path, temp_path);
        }
    } else {
        // ��ͨ·��
        char normalized[MAX_PATH_LEN];
        strcpy(normalized, virtual_path);
        normalize_path(normalized);

        if (strcmp(normalized, "/") == 0) {
            strcpy(real_path, BUILDS_DIR);
        } else {
            const char *rel_path = (normalized[0] == '/') ? normalized + 1 : normalized;
            snprintf(temp_path, MAX_PATH_LEN, "%s\\%s", BUILDS_DIR, rel_path);

            // ��·���е�/�滻Ϊ
            for (i = 0; temp_path[i] != '\0'; i++) {
                if (temp_path[i] == '/') {
                    temp_path[i] = '\\';
                }
            }
            strcpy(real_path, temp_path);
        }
    }
}



// ���·���Ƿ���Ŀ¼
int is_directory(const char *path) {
    struct _finddata_t fileinfo;
    intptr_t handle = _findfirst(path, &fileinfo);

    if (handle == -1L) {
        return 0;  /* �ļ������� */
    }

    int is_dir = (fileinfo.attrib & _A_SUBDIR) != 0;
    _findclose(handle);
    return is_dir;
}


// ���·���Ƿ����ļ�
int is_file(const char *path) {
    struct _finddata_t fileinfo;
    intptr_t handle = _findfirst(path, &fileinfo);

    if (handle == -1L) {
        return 0;  /* �ļ������� */
    }

    int is_file = (fileinfo.attrib & _A_SUBDIR) == 0;
    _findclose(handle);
    return is_file;
}


// �����������Ƴ��ַ������˵�����
void remove_quotes(char *str) {
    int len = strlen(str);

    if (len >= 2) {
        if ((str[0] == '"' && str[len-1] == '"') ||
            (str[0] == '\'' && str[len-1] == '\'')) {
            // �ƶ��ַ������ݣ�ȥ������
            for (int i = 0; i < len - 2; i++) {
                str[i] = str[i+1];
            }
            str[len-2] = '\0';
        }
    }
}

